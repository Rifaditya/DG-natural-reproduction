scoreboard players set #ambient nr_naturalist 0
execute as @e[type=#nr_naturalist:ambient_mobs,tag=nr_breeding_blocked] run data merge entity @s {Age:0}
execute as @e[type=#nr_naturalist:ambient_mobs,tag=nr_breeding_blocked] run tag @s remove nr_breeding_blocked
playsound minecraft:ui.button.click master @a ~ ~ ~ 1 1.2
title @a actionbar {"text":"[Natural Reproduction] Breeding ENABLED for Ambient Mobs","color":"green"}
tellraw @a [{"text":"[Natural Reproduction] ","color":"gold","bold":true},{"text":"Ambient bugs & birds breeding: ","color":"yellow"},{"text":"ENABLED","color":"green","bold":true}]
function nr_naturalist:menu
